#sayournames.py-lets everybody print thier name on screen
#Ask the user for thier name
name=input  ("What is your name?")
  #Keep printing until we want to quit
       #print thier name 100 times
      for x in range(100):
        #print thier name followed by a space, not a new line 
        print(name, end= "")  
        print() #after the loop