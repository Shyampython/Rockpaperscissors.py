# saymyname.py
# Ask the user for thier name
name = input("What is your name?")
# print thier name 100 times
for x in range(100):
  #  Print thier name followed by a space,not a new line
  print(name, end = "rules")