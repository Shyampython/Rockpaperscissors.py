list(range(10)
