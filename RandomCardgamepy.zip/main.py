import random
suits = ["clubs","Diamonds","hearts","spades"]
faces = ["two", "three","four","five","six","seven","eight","nine","ten","Jack","king","Queen"]
my_face = random.choices(faces)
my_suit = random.choice(suits)
print("I have the", my_face, "of", my_suit)