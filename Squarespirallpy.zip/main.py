import turtle
t=turtle.pen()

  t.forward(60)
  t.left(90)